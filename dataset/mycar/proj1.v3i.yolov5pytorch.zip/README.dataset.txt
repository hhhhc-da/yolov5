# proj1 > 2024-08-07 5:47pm
https://universe.roboflow.com/nanoka/proj1-esgnc

Provided by a Roboflow user
License: MIT

